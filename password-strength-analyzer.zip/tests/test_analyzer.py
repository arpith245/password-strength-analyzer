import pytest
from password_strength_tool import analyzer

def test_entropy_basic():
    assert analyzer.entropy("abc") > 0

def test_leet_variants():
    v = analyzer.leet_variants("pass")
    assert "p@ss" in v or "p4ss" in v
