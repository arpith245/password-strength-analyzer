#!/usr/bin/env python3
"""
Password Strength Analyzer & Custom Wordlist Generator
Author: Abhay
"""

import argparse, itertools, math, re
from pathlib import Path
try:
    from zxcvbn import zxcvbn
    ZXC = True
except:
    ZXC = False

LEETS = {'a':['a','4','@'], 'e':['e','3'], 'i':['i','1','!'], 'o':['o','0'], 's':['s','5','$']}
SEPARATORS = ['', '.', '_', '-']

def entropy(password):
    chars = 0
    if re.search(r'[a-z]', password): chars += 26
    if re.search(r'[A-Z]', password): chars += 26
    if re.search(r'[0-9]', password): chars += 10
    if re.search(r'[^A-Za-z0-9]', password): chars += 32
    return len(password)*math.log2(chars) if chars else 0

def analyze(password):
    if ZXC:
        r = zxcvbn(password)
        return {'score': r['score'], 'entropy': r['entropy'], 'feedback': r['feedback']}
    else:
        e = entropy(password)
        return {'score': None, 'entropy': e, 'feedback': {'suggestions': ['Use longer password', 'Add numbers/symbols']}}

def leet_variants(word):
    combos = ['']
    for ch in word:
        new = []
        for c in combos:
            new += [c + v for v in LEETS.get(ch.lower(), [ch])]
        combos = new
    return list(set(combos))

def generate_wordlist(hints, years=(2000,2025), limit=3000):
    tokens = set()
    for h in hints:
        tokens.add(h)
        tokens.update(leet_variants(h))
    words = set()
    for r in range(1, 3):
        for p in itertools.permutations(tokens, r):
            for sep in SEPARATORS:
                w = sep.join(p)
                words.add(w)
                for y in range(years[0], years[1]+1, 5):
                    words.add(w + str(y))
            if len(words) > limit: break
        if len(words) > limit: break
    return list(words)[:limit]

def save_wordlist(words, out):
    with open(out, 'w') as f:
        for w in words:
            f.write(w+'\n')
    print(f"[+] Saved {len(words)} words to {out}")

def main():
    parser = argparse.ArgumentParser(description="Password Strength Analyzer & Wordlist Generator")
    sub = parser.add_subparsers(dest="cmd")

    a = sub.add_parser("analyze")
    a.add_argument("--password", required=True)

    g = sub.add_parser("generate")
    g.add_argument("--hints", nargs="+", required=True)
    g.add_argument("--out", default="wordlist.txt")


    args = parser.parse_args()

    if args.cmd == "analyze":
        res = analyze(args.password)
        print(res)
    elif args.cmd == "generate":
        wl = generate_wordlist(args.hints)
        save_wordlist(wl, args.out)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
