# 🔐 Password Strength Analyzer & Custom Wordlist Generator

A Python tool that analyzes password strength and generates custom wordlists.

## 🚀 Usage

### Install dependencies
```bash
pip install -r requirements.txt
```

### Analyze password
```bash
python password_strength_tool/analyzer.py analyze --password "P@ssw0rd123"
```

### Generate wordlist
```bash
python password_strength_tool/analyzer.py generate --hints abhay dog 2001 --out abhay_wordlist.txt
```
